"""Wrapper sencillo para la API Dragonfish"""
from __future__ import annotations

import requests
import json
from datetime import datetime

from utils import config
from utils.logger import get_logger
from .base import APIError

log = get_logger(__name__)

BASE_URL = "http://190.211.201.217:8009/api.Dragonfish"


def _headers() -> dict:
    return {
        "accept": "application/json",
        "Authorization": config.DRAGONFISH_TOKEN,
        "Content-Type": "application/json",
        "BaseDeDatos": "DEPOSITO",
    }


def _fecha_dragonfish() -> str:
    return datetime.now().strftime("%d/%m/%Y")


def _hora_dragonfish() -> str:
    return datetime.now().strftime("%H:%M:%S")


def send_stock_movement(pedido_id: int | str, codigo_barra: str, cantidad: int, datos_articulo: dict) -> None:
    url = f"{BASE_URL}/Movimientodestock/"
    body = {
        "OrigenDestino": "WOO",
        "Tipo": 2,
        "Motivo": "API",
        "vendedor": "API",
        "Remito": "-",
        "CompAfec": [],
        "Fecha": _fecha_dragonfish(),
        "Observacion": f"MELI API {pedido_id}",
        "MovimientoDetalle": [
            {
                "Articulo": datos_articulo.get("CODIGO_BARRA", codigo_barra),
                "ArticuloDetalle": datos_articulo.get("ARTDES", ""),
                "Color": datos_articulo.get("CODIGO_COLOR"),
                "Talle": datos_articulo.get("CODIGO_TALLE"),
                "Cantidad": cantidad,
                "NroItem": 1,
            }
        ],
        "InformacionAdicional": {
            "FechaAltaFW": _fecha_dragonfish(),
            "HoraAltaFW": _hora_dragonfish(),
            "EstadoTransferencia": "PENDIENTE",
            "BaseDeDatosAltaFW": "DEPOSITO",
            "BaseDeDatosModificacionFW": "DEPOSITO",
            "SerieAltaFW": "901224",
            "SerieModificacionFW": "901224",
            "UsuarioAltaFW": "API",
            "UsuarioModificacionFW": "API",
        },
    }

    log.debug("Dragonfish payload: %s", json.dumps(body, ensure_ascii=False)[:500])
    resp = requests.post(url, headers=_headers(), data=json.dumps(body))
    if resp.status_code != 200:
        raise APIError.from_response(resp)
